import axios from 'axios';

const API_URL = 'http://localhost:8080/api/biblioteca';

export const getBooks = async () => {
  return await axios.get(`${API_URL}/libri`);
};

export const deleteBook = async (id) => {
  return await axios.delete(`${API_URL}/libro/${id}`);
};

export const addBook = async (bookData, coverFile) => {
  const formData = new FormData();
  formData.append('libro', JSON.stringify(bookData));
  if (coverFile) formData.append('copertina', coverFile);
  return await axios.post(`${API_URL}/libro`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
};

// Add other methods (update, search, etc.) here