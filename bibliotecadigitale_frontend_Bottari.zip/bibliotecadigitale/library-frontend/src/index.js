import React from 'react';
import MainLayout from './layouts/MainLayout';
import BookGrid from './components/BookGrid';

const Home = () => {
  return (
    <MainLayout>
      <BookGrid />
      <button className="try-button">ESPLORA CATALOGO</button>
    </MainLayout>
  );
};

export default Home;