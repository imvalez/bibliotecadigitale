import React, { useEffect, useState } from 'react';
import { getBooks } from '../services/apiService';
import BookCard from './BookCard';

const BookGrid = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await getBooks();
        setBooks(response.data);
      } catch (error) {
        console.error('Errore:', error);
      }
    };
    fetchBooks();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm('Sei sicuro di voler eliminare questo libro?')) {
      await deleteBook(id);
      setBooks(books.filter(book => book.id !== id));
    }
  };

  return (
    <div className="book-grid">
      {books.map(book => (
        <BookCard 
          key={book.id} 
          book={book} 
          onDelete={handleDelete} 
        />
      ))}
    </div>
  );
};

export default BookGrid;