import React from 'react';
import { Link } from 'react-router-dom';

const BookCard = ({ book, onDelete }) => (
  <div className="book-card">
    <img 
      src={`/api/biblioteca/libro/${book.id}/copertina`} 
      alt={book.titolo}
      className="book-image"
      onError={(e) => (e.target.src = "/api/placeholder/250/300")}
    />
    <div className="book-info">
      <h3 className="book-title">{book.titolo}</h3>
      <p className="book-author">
        {book.autore?.nome} {book.autore?.cognome}
      </p>
    </div>
    <div className="book-actions">
      <div className="social-icons">
        <span>📚</span>
        <span>⭐</span>
        <span>📖</span>
      </div>
      <button 
        className="delete-button"
        onClick={() => onDelete(book.id)}
      >
        Elimina
      </button>
    </div>
  </div>
);

export default BookCard;