import React, { useState } from 'react';

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    terms: false
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Le password non coincidono!');
      return;
    }
    // Implement registration logic here
  };

  return (
    <div className="register-container">
      <div className="register-header">
        <h2>Crea il tuo account</h2>
        <p>Inizia a collezionare i tuoi libri preferiti</p>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group">
            <label>Nome</label>
            <input 
              name="firstName" 
              value={formData.firstName} 
              onChange={handleChange} 
              required 
            />
          </div>
          <div className="form-group">
            <label>Cognome</label>
            <input 
              name="lastName" 
              value={formData.lastName} 
              onChange={handleChange} 
              required 
            />
          </div>
        </div>
        <div className="form-group">
          <label>Email</label>
          <input 
            type="email" 
            name="email" 
            value={formData.email} 
            onChange={handleChange} 
            required 
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input 
            type="password" 
            name="password" 
            value={formData.password} 
            onChange={handleChange} 
            required 
          />
        </div>
        <div className="form-group">
          <label>Conferma Password</label>
          <input 
            type="password" 
            name="confirmPassword" 
            value={formData.confirmPassword} 
            onChange={handleChange} 
            required 
          />
        </div>
        <div className="terms">
          <input 
            type="checkbox" 
            name="terms" 
            checked={formData.terms} 
            onChange={handleChange} 
            required 
          />
          <label htmlFor="terms">
            Accetto i <a href="#">Termini di Servizio</a> e la <a href="#">Privacy Policy</a>
          </label>
        </div>
        <button type="submit" className="register-button">
          Registrati
        </button>
      </form>
    </div>
  );
};

export default RegisterForm;