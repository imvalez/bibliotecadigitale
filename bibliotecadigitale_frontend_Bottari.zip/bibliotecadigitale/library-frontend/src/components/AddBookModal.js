import React, { useState } from 'react';
import { addBook } from '../services/apiService';

const AddBookModal = () => {
  const [formData, setFormData] = useState({
    titolo: '',
    autoreId: 1,
    // Add other fields
  });
  const [coverFile, setCoverFile] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addBook(formData, coverFile);
      alert('Libro aggiunto!');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="modal">
      <form onSubmit={handleSubmit}>
        {/* Book form fields */}
        <input type="file" onChange={(e) => setCoverFile(e.target.files[0])} />
        <button type="submit">Aggiungi</button>
      </form>
    </div>
  );
};

export default AddBookModal;