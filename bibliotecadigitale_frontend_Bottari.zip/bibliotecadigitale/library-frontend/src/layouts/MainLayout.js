import React from 'react';
//import { Link } from 'react-router-dom';
import '../styles/GlobalStyles.css';

const MainLayout = ({ children }) => (
  <div className="app-container">
    {/* Header */}
    <header className="header">
      <button className="back-button">&larr;</button>
      <div className="title">
        <h1>La Mia Biblioteca</h1>
        <span>La tua libreria digitale</span>
      </div>
    </header>

    {/* Main Content */}
    {children}

    {/* Footer */}
    <footer className="footer">
      <div className="logo">Biblioteca</div>
      <div className="curated-by">powered by Valerio Bottari & Francesco Gazziano</div>
    </footer>
  </div>
);

export default MainLayout;