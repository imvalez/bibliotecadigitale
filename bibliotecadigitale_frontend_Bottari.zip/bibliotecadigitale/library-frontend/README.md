# 📌 Istruzioni per il Backendista

## 🚀 Richieste Specifiche
### 📚 Implementazione dei Metodi del Service
Il file `LibroService.java` deve avere implementazioni complete per:
- `getAllLibri()`: Recupera tutti i libri disponibili.
- `getLibroById(id)`: Restituisce il libro con l'ID specificato.
- `addLibro(libro, copertina)`: Aggiunge un nuovo libro con la copertina.
- `updateLibro(id, libro, copertina)`: Aggiorna le informazioni di un libro esistente.
- `deleteLibro(id)`: Elimina un libro tramite ID.
- Metodi di ricerca/filtri: (es. `cercaLibri(keyword)`) per filtrare i libri per titolo, autore, categoria, ecc.

---

## 🧪 Test dei Dati di Esempio
Assicurarsi di popolare il database con almeno **5 libri di esempio** comprensivi di:
- **Autori**
- **Categorie**
- **Editori**
- **Copertine**

---

## 🛠️ Configurazione del Database
Verificare che le tabelle siano correttamente create:
- **Libro** 📖
- **Autore** ✍️
- **Categoria** 📂
- **Editore** 🏢

---

## 🔄 Risposte di Fallback
Se una copertina non è disponibile, restituire un **placeholder** con il seguente endpoint:
```
/api/placeholder/250/300
```

---

## 📥 Esempio di Risposta Attesa per un Libro
```json
{
  "id": 1,
  "titolo": "Il Nome della Rosa",
  "descrizione": "Un giallo medievale...",
  "autore": {
    "id": 1,
    "nome": "Umberto",
    "cognome": "Eco"
  },
  "categoria": {
    "id": 2,
    "nome": "Romanzo"
  },
  "copertinaType": "image/jpeg",
  "copertinaName": "copertina.jpg"
}
```

---

## ✅ Checklist Finale
✔️ Tutti gli endpoint sono raggiungibili e restituiscono dati validi.  
✔️ I file delle copertine sono salvati correttamente.  
✔️ I metodi di ricerca e filtri funzionano correttamente.  
✔️ I dati di esempio sono presenti nel database.  

---

🔎 **Assicurati di testare ogni funzionalità prima di rilasciare il codice!** 🚀

